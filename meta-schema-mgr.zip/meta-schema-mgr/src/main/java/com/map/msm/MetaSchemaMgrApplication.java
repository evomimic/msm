package com.map.msm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetaSchemaMgrApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetaSchemaMgrApplication.class, args);
	}
}
